export const formatDate = (stringValue) => {
    return stringValue.replace(/\//g, '.');
}